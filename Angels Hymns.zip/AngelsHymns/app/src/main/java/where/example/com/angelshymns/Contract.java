package where.example.com.angelshymns;

/**
 * Created by Antoun on 4/8/2017.
 */

public class Contract {
        public static final class HymnEntry {
            public static final String TABLE_NAME = "hymns";
            public static final String COLUMN_ID = "id";
            public static final String NAME = "name";
            public static final String CONTENT = "content";
            public static final String CONTENT_COPTIC = "content_coptic";
        }
    }


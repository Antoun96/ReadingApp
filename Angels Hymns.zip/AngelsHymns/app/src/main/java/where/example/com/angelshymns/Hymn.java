package where.example.com.angelshymns;

import java.io.Serializable;

/**
 * Created by Antoun on 4/8/2017.
 */

public class Hymn implements Serializable{
    int id ;
    String name ;
    String content ;
    String content_coptic;
}
